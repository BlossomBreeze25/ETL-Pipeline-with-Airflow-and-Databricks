from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
from airflow.operators.empty import EmptyOperator

default_args = {
    'owner': 'data_engineering',
    'depends_on_past': False,
    'email_on_failure': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

with DAG(
    dag_id='databricks_automated_etl',
    default_args=default_args,
    description='Production Airflow pipeline submitting jobs to an ephemeral Databricks cluster',
    schedule_interval='@daily',
    start_date=datetime(2026, 1, 1),
    catchup=False,
    tags=['etl', 'databricks', 'spark'],
) as dag:

    start = EmptyOperator(task_id='start')

    # Defines an automated run configuration using dynamic cluster provisioning
    new_cluster_spec = {
        'spark_version': '13.3.x-scala2.12',
        'node_type_id': 'i3.xlarge',
        'num_workers': 2,
        'aws_attributes': {
            'availability': 'SPOT',
            'zone_id': 'us-east-1a'
        }
    }

    submit_etl_job = DatabricksSubmitRunOperator(
        task_id='submit_databricks_etl',
        databricks_conn_id='databricks_default',
        new_cluster=new_cluster_spec,
        spark_jar_task={
            'main_class_name': 'com.databricks.apps.ETLPipeline'
        },
        # Alternatively for notebook tasks, swap spark_jar_task with:
        # notebook_task={
        #     'notebook_path': '/Shared/production_etl_pipeline',
        #     'base_parameters': {'execution_date': '{{ ds }}'}
        # },
    )

    end = EmptyOperator(task_id='end')

    start >> submit_etl_job >> end
